let booksData = [];
let wishlist = [];

// Fetch and display books
async function fetchBooks() {
  try {
    const response = await fetch("../data/books.json");
    if (!response.ok) {
      throw new Error("Грешка при вчитување на книгите!");
    }
    booksData = await response.json();
    displayBooks(booksData);
  } catch (error) {
    console.error("Грешка:", error.message);
  }
}

// Display books in the library
function displayBooks(books) {
  const bookList = document.getElementById("bookList");
  bookList.innerHTML = "";

  books.forEach(book => {
    const col = document.createElement("div");
    col.className = "col-md-4 mb-4";

    col.innerHTML = `
      <div class="card h-100">
        <img src="../assets/images/${book.cover}" class="card-img-top" alt="${book.title}" style="height: 250px; object-fit: cover;">
        <div class="card-body">
          <h6 class="text-muted">ID: ${book.id}</h6>
          <h5 class="card-title">${book.title}</h5>
          <h6 class="card-subtitle mb-2 text-muted">${book.author}</h6>
          <p class="card-text">${book.description || ""}</p>
          <button class="btn btn-primary btn-sm" onclick="addToWishlist('${book.id}')">
            Add to Wishlist
          </button>
        </div>
      </div>
    `;

    bookList.appendChild(col);
  });
}

// Add to Wishlist by book ID
function addToWishlist(bookId) {
  const book = booksData.find(b => b.id === bookId);
  if (!book) return;

  if (!wishlist.find(item => item.id === book.id)) {
    wishlist.push(book);
    saveWishlist();
    alert(`${book.title} has been added to your wishlist!`);
  } else {
    alert(`${book.title} is already in your wishlist!`);
  }
}

// Save Wishlist to localStorage
function saveWishlist() {
  localStorage.setItem("wishlist", JSON.stringify(wishlist));
}

// Load Wishlist from localStorage
function loadWishlist() {
  const storedWishlist = localStorage.getItem("wishlist");
  if (storedWishlist) {
    wishlist = JSON.parse(storedWishlist);
  }
}

// Display Wishlist
function displayWishlist() {
  const wishlistContainer = document.getElementById("wishlist");
  wishlistContainer.innerHTML = "";

  if (wishlist.length === 0) {
    wishlistContainer.innerHTML = "<p>Your wishlist is empty.</p>";
    return;
  }

  wishlist.forEach(book => {
    const col = document.createElement("div");
    col.className = "col-md-4 mb-4";

    col.innerHTML = `
      <div class="card h-100">
        <img src="../assets/images/${book.cover}" class="card-img-top" alt="${book.title}" style="height: 250px; object-fit: cover;">
        <div class="card-body">
          <h6 class="text-muted">ID: ${book.id}</h6>
          <h5 class="card-title">${book.title}</h5>
          <h6 class="card-subtitle mb-2 text-muted">${book.author}</h6>
          <p class="card-text">${book.description || ""}</p>
          <button class="btn btn-danger btn-sm" onclick="removeFromWishlist('${book.id}')">Remove</button>
        </div>
      </div>
    `;

    wishlistContainer.appendChild(col);
  });
}

// Remove from Wishlist
function removeFromWishlist(bookId) {
  wishlist = wishlist.filter(book => book.id !== bookId);
  saveWishlist();
  displayWishlist();
}

loadWishlist();
fetchBooks();
